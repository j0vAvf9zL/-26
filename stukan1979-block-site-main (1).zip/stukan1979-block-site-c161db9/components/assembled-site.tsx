import { ArrowRight, Globe, Image as ImageIcon, Sparkles } from "lucide-react";
import type { GeneratedBlock } from "@/lib/block-generator";

interface AssembledSiteProps {
  topic: string;
  blocks: GeneratedBlock[];
}

function siteTitle(topic: string): string {
  const trimmed = topic.trim();
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
}

function siteSlug(topic: string): string {
  const slug = topic
    .trim()
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32);
  return slug || "site";
}

export function AssembledSite({ topic, blocks }: AssembledSiteProps) {
  const title = siteTitle(topic);
  const slug = siteSlug(topic);
  const heroImage = blocks.find((block) => block.image)?.image ?? null;
  const firstBlockId = blocks[0]?.id ?? "content";

  return (
    <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
      <div className="flex items-center gap-2 border-b bg-muted/40 px-4 py-2.5">
        <div aria-hidden className="flex gap-1.5">
          <span className="h-3 w-3 rounded-full bg-rose-300" />
          <span className="h-3 w-3 rounded-full bg-amber-300" />
          <span className="h-3 w-3 rounded-full bg-emerald-300" />
        </div>
        <div className="mx-auto flex items-center gap-1.5 rounded-md bg-background px-3 py-1 text-xs text-muted-foreground">
          <Globe className="h-3 w-3" />
          blocksite.app/{slug}
        </div>
        <span className="sr-only">
          Предпросмотр автоматически собранного сайта
        </span>
      </div>

      <article className="bg-white text-slate-900">
        <header className="sticky top-14 z-10 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4 sm:px-6">
            <span className="text-base font-bold tracking-tight">{title}</span>
            <nav className="hidden gap-5 text-sm text-slate-600 md:flex">
              {blocks.map((block) => (
                <a
                  key={block.id}
                  href={`#${block.id}`}
                  className="transition-colors hover:text-slate-900"
                >
                  {block.title}
                </a>
              ))}
            </nav>
          </div>
        </header>

        <section className="relative overflow-hidden">
          {heroImage ? (
            <img
              src={heroImage}
              alt=""
              aria-hidden
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : null}
          <div
            className={
              heroImage
                ? "relative mx-auto max-w-5xl bg-slate-900/60 px-4 py-20 text-center text-white sm:px-6 sm:py-28"
                : "gradient-hero-vibrant relative mx-auto max-w-5xl px-4 py-20 text-center text-slate-900 sm:px-6 sm:py-28"
            }
          >
            <p className="text-sm font-semibold tracking-widest uppercase opacity-80">
              Готовый сайт по теме «{topic}»
            </p>
            <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-6xl">
              {title}
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed opacity-90">
              Сайт автоматически собран из смысловых блоков и фотографий.
              Заголовки, тексты и изображения обновляются при каждой правке.
            </p>
            <a
              href={`#${firstBlockId}`}
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-900 shadow-lg transition-transform hover:scale-105"
            >
              Смотреть содержание
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </section>

        <div
          id="content"
          className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-20"
        >
          {blocks.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-slate-200 px-6 py-14 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
                <ImageIcon className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm text-slate-500">
                В собранном сайте пока нет блоков — вернитесь в редактор и
                добавьте хотя бы один.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-16">
              {blocks.map((block, index) => (
                <section
                  key={block.id}
                  id={block.id}
                  className="grid scroll-mt-28 items-center gap-8 sm:grid-cols-2"
                >
                  <div className={index % 2 === 1 ? "sm:order-2" : undefined}>
                    {block.image ? (
                      <img
                        src={block.image}
                        alt={block.title}
                        loading="lazy"
                        className="aspect-[4/3] w-full rounded-2xl object-cover shadow-md"
                      />
                    ) : (
                      <div className="flex aspect-[4/3] w-full items-center justify-center rounded-2xl bg-slate-100">
                        <ImageIcon className="h-10 w-10 text-slate-300" />
                      </div>
                    )}
                  </div>
                  <div className={index % 2 === 1 ? "sm:order-1" : undefined}>
                    <p className="flex items-center gap-2 text-xs font-semibold tracking-widest text-indigo-500 uppercase">
                      <Sparkles className="h-3.5 w-3.5" />
                      Раздел {index + 1}
                    </p>
                    <h2 className="mt-2 text-3xl font-bold tracking-tight">
                      {block.title}
                    </h2>
                    <p className="mt-4 leading-relaxed text-slate-600">
                      {block.text}
                    </p>
                  </div>
                </section>
              ))}
            </div>
          )}
        </div>

        <footer className="border-t border-slate-200">
          <div className="mx-auto max-w-5xl px-4 py-8 text-center text-sm text-slate-500 sm:px-6">
            © {new Date().getFullYear()} {title}. Сайт собран автоматически
            сервисом БлокСайт.
          </div>
        </footer>
      </article>
    </div>
  );
}
