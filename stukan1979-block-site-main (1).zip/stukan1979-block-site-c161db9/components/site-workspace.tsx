"use client";

import { useEffect, useRef, useState } from "react";
import {
  CloudCheck,
  CloudOff,
  Globe,
  LayoutPanelTop,
  ListPlus,
  LoaderCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AssembledSite } from "@/components/assembled-site";
import { BlocksBoard } from "@/components/blocks-board";
import type { BlocksResult, GeneratedBlock } from "@/lib/block-generator";
import type { SavedSite } from "@/lib/models";

type WorkspaceView = "site" | "blocks";
type SaveStatus = "idle" | "saving" | "saved" | "error";

const AUTOSAVE_DELAY_MS = 800;

function pluralizeSources(count: number): string {
  if (count % 10 === 1 && count % 100 !== 11) return `${count} источник`;
  if (
    count % 10 >= 2 &&
    count % 10 <= 4 &&
    (count % 100 < 12 || count % 100 > 14)
  ) {
    return `${count} источника`;
  }
  return `${count} источников`;
}

interface SiteWorkspaceProps {
  result: BlocksResult;
  initialSiteId?: string | null;
  onSiteSaved?: () => void;
}

export function SiteWorkspace({
  result,
  initialSiteId,
  onSiteSaved,
}: SiteWorkspaceProps) {
  const [blocks, setBlocks] = useState<GeneratedBlock[]>(result.blocks);
  const [view, setView] = useState<WorkspaceView>("site");
  const [siteId, setSiteId] = useState<string | null>(initialSiteId ?? null);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const didMountRef = useRef(false);

  useEffect(() => {
    if (initialSiteId) return;

    let cancelled = false;
    setSaveStatus("saving");

    async function createRecord() {
      try {
        const response = await fetch("/api/sites", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            topic: result.topic,
            blocks: result.blocks,
            autoPicked: result.autoPicked,
            sources: result.sources,
          }),
        });
        if (!response.ok) throw new Error("create failed");
        const saved = (await response.json()) as SavedSite;
        if (cancelled) return;
        setSiteId(saved.id);
        setSaveStatus("saved");
        onSiteSaved?.();
      } catch {
        if (!cancelled) setSaveStatus("error");
      }
    }

    void createRecord();
    return () => {
      cancelled = true;
    };
  }, [result, initialSiteId, onSiteSaved]);

  useEffect(() => {
    if (!didMountRef.current) {
      didMountRef.current = true;
      return;
    }
    if (!siteId) return;

    setSaveStatus("saving");
    const timer = setTimeout(async () => {
      try {
        const response = await fetch("/api/sites", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: siteId,
            topic: result.topic,
            blocks,
            autoPicked: result.autoPicked,
            sources: result.sources,
          }),
        });
        if (!response.ok) throw new Error("update failed");
        setSaveStatus("saved");
        onSiteSaved?.();
      } catch {
        setSaveStatus("error");
      }
    }, AUTOSAVE_DELAY_MS);

    return () => clearTimeout(timer);
  }, [blocks, siteId, result, onSiteSaved]);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-primary">
            {result.autoPicked
              ? "Автоподбор из интернета"
              : "Автоматический подбор"}
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight">
            Смысловые блоки по теме «{result.topic}»
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Сайт сохраняется автоматически при каждой правке — открыть его можно
            из списка сохранённых сайтов.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary" className="gap-1.5 px-3 py-1">
            <Globe className="h-3.5 w-3.5" />
            {result.autoPicked
              ? pluralizeSources(result.sources)
              : "по базе знаний"}
          </Badge>
          {saveStatus === "saving" ? (
            <Badge variant="secondary" className="gap-1.5 px-3 py-1">
              <LoaderCircle className="h-3.5 w-3.5 animate-spin" />
              Сохраняем…
            </Badge>
          ) : saveStatus === "saved" ? (
            <Badge
              variant="secondary"
              className="gap-1.5 border-emerald-200 bg-emerald-50 px-3 py-1 text-emerald-700"
            >
              <CloudCheck className="h-3.5 w-3.5" />
              Сохранено
            </Badge>
          ) : saveStatus === "error" ? (
            <Badge variant="destructive" className="gap-1.5 px-3 py-1">
              <CloudOff className="h-3.5 w-3.5" />
              Не сохранилось
            </Badge>
          ) : null}
        </div>
      </div>

      <div className="mb-6 inline-flex rounded-xl border bg-background p-1 shadow-sm">
        <Button
          type="button"
          variant={view === "site" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => setView("site")}
        >
          <LayoutPanelTop />
          Готовый сайт
        </Button>
        <Button
          type="button"
          variant={view === "blocks" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => setView("blocks")}
        >
          <ListPlus />
          Редактор блоков
        </Button>
      </div>

      {view === "site" ? (
        <AssembledSite topic={result.topic} blocks={blocks} />
      ) : (
        <BlocksBoard
          blocks={blocks}
          onBlocksChange={setBlocks}
          topic={result.topic}
        />
      )}
    </div>
  );
}
