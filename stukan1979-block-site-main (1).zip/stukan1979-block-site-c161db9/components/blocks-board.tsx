"use client";

import { useState } from "react";
import {
  Blocks,
  BookOpen,
  Heart,
  Image as ImageIcon,
  ImageOff,
  Lightbulb,
  MapPin,
  Pencil,
  Plus,
  Sparkles,
  Star,
  Target,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogMedia,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardAction,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { BlockFormDialog } from "@/components/block-form-dialog";
import { PhotoPickerDialog } from "@/components/photo-picker-dialog";
import type { GeneratedBlock } from "@/lib/block-generator";
import type { BlockFormValues } from "@/lib/validation/block";

const BLOCK_ICONS = [
  Heart,
  MapPin,
  Sparkles,
  Lightbulb,
  Star,
  Target,
  BookOpen,
  TrendingUp,
];

const BLOCK_GRADIENTS = [
  "from-rose-100 to-orange-100",
  "from-amber-100 to-yellow-100",
  "from-emerald-100 to-teal-100",
  "from-sky-100 to-indigo-100",
  "from-violet-100 to-fuchsia-100",
];

function createId(): string {
  return crypto.randomUUID();
}

async function fetchPhotoCandidates(
  topic: string,
  title: string
): Promise<string[]> {
  const params = new URLSearchParams();
  if (topic) params.set("topic", topic);
  params.set("title", title);
  const response = await fetch(`/api/photos?${params.toString()}`);
  if (!response.ok) throw new Error("Не удалось подобрать фотографии");
  const data = (await response.json()) as { photos: string[] };
  return data.photos;
}

export function BlocksBoard({
  blocks,
  onBlocksChange,
  topic,
}: {
  blocks: GeneratedBlock[];
  onBlocksChange: React.Dispatch<React.SetStateAction<GeneratedBlock[]>>;
  topic: string;
}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBlock, setEditingBlock] = useState<GeneratedBlock | null>(null);
  const [deletingBlock, setDeletingBlock] = useState<GeneratedBlock | null>(
    null
  );
  const [photoBlock, setPhotoBlock] = useState<GeneratedBlock | null>(null);

  function openAdd() {
    setEditingBlock(null);
    setDialogOpen(true);
  }

  function openEdit(block: GeneratedBlock) {
    setEditingBlock(block);
    setDialogOpen(true);
  }

  async function pickPhotoForBlock(block: GeneratedBlock) {
    try {
      const candidates = await fetchPhotoCandidates(topic, block.title);
      if (candidates.length === 0) return;
      onBlocksChange((prev) =>
        prev.map((item) =>
          item.id === block.id
            ? {
                ...item,
                image: item.image ?? candidates[0],
                imageCandidates: candidates,
              }
            : item
        )
      );
    } catch {
      // Фото не подобралось — блок остаётся без фотографии, ошибка не фатальна
    }
  }

  function handleSubmit(values: BlockFormValues) {
    if (editingBlock) {
      onBlocksChange((prev) =>
        prev.map((block) =>
          block.id === editingBlock.id ? { ...block, ...values } : block
        )
      );
      toast.success("Блок обновлён");
    } else {
      const newBlock: GeneratedBlock = {
        id: createId(),
        title: values.title,
        text: values.text,
        image: null,
        imageCandidates: [],
      };
      onBlocksChange((prev) => [...prev, newBlock]);
      toast.success("Блок добавлен");
      void pickPhotoForBlock(newBlock);
    }
  }

  function handleDelete() {
    if (!deletingBlock) return;
    onBlocksChange((prev) =>
      prev.filter((block) => block.id !== deletingBlock.id)
    );
    toast.success("Блок удалён");
    setDeletingBlock(null);
  }

  function handleSelectPhoto(url: string) {
    if (!photoBlock) return;
    onBlocksChange((prev) =>
      prev.map((block) =>
        block.id === photoBlock.id
          ? {
              ...block,
              image: url,
              imageCandidates: block.imageCandidates.includes(url)
                ? block.imageCandidates
                : [url, ...block.imageCandidates],
            }
          : block
      )
    );
    toast.success("Фотография блока заменена");
    setPhotoBlock(null);
  }

  function handleRemovePhoto(block: GeneratedBlock) {
    onBlocksChange((prev) =>
      prev.map((item) =>
        item.id === block.id ? { ...item, image: null } : item
      )
    );
    toast.success("Фотография убрана");
  }

  return (
    <>
      {blocks.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed bg-background px-6 py-14 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <Blocks className="h-6 w-6 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground">
            Все блоки удалены. Добавьте свой первый блок.
          </p>
          <Button type="button" onClick={openAdd}>
            <Plus />
            Добавить блок
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {blocks.map((block, index) => {
            const Icon = BLOCK_ICONS[index % BLOCK_ICONS.length];
            const gradient = BLOCK_GRADIENTS[index % BLOCK_GRADIENTS.length];
            return (
              <Card
                key={block.id}
                className="card-hover relative animate-in fade-in slide-in-from-bottom-4 duration-500"
                style={{ animationDelay: `${index * 80}ms` }}
              >
                {block.image ? (
                  <img
                    src={block.image}
                    alt={block.title}
                    loading="lazy"
                    className="h-32 w-full object-cover"
                  />
                ) : (
                  <div
                    aria-hidden
                    className={`-mt-4 flex h-32 items-center justify-center bg-gradient-to-br ${gradient}`}
                  >
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/70 text-foreground shadow-sm">
                      <Icon className="h-7 w-7" />
                    </div>
                  </div>
                )}

                <div className="absolute top-2 right-2 z-10 flex gap-1">
                  <Button
                    type="button"
                    variant="secondary"
                    size="icon-sm"
                    aria-label={
                      block.image
                        ? "Заменить фотографию"
                        : "Добавить фотографию"
                    }
                    onClick={() => setPhotoBlock(block)}
                  >
                    <ImageIcon />
                  </Button>
                  {block.image ? (
                    <Button
                      type="button"
                      variant="secondary"
                      size="icon-sm"
                      aria-label="Убрать фотографию"
                      onClick={() => handleRemovePhoto(block)}
                    >
                      <ImageOff />
                    </Button>
                  ) : null}
                </div>

                <CardHeader>
                  <CardTitle>{block.title}</CardTitle>
                  <CardAction>
                    <div className="flex gap-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        aria-label="Редактировать блок"
                        onClick={() => openEdit(block)}
                      >
                        <Pencil />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        aria-label="Удалить блок"
                        onClick={() => setDeletingBlock(block)}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                  </CardAction>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {block.text}
                  </p>
                </CardContent>
              </Card>
            );
          })}
          <button
            type="button"
            onClick={openAdd}
            className="group flex min-h-40 flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-background px-6 py-10 text-center transition-colors hover:border-primary/40 hover:bg-muted/40"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted transition-colors group-hover:bg-primary/10">
              <Plus className="h-6 w-6 text-muted-foreground" />
            </div>
            <span className="text-sm font-medium">Добавить свой блок</span>
            <span className="text-xs text-muted-foreground">
              Введите заголовок и текст нового блока
            </span>
          </button>
        </div>
      )}

      <BlockFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode={editingBlock ? "edit" : "add"}
        initial={editingBlock ?? undefined}
        onSubmit={handleSubmit}
      />

      <PhotoPickerDialog
        open={photoBlock !== null}
        onOpenChange={(open) => {
          if (!open) setPhotoBlock(null);
        }}
        title={photoBlock?.title ?? ""}
        topic={topic}
        currentImage={photoBlock?.image ?? null}
        initialCandidates={photoBlock?.imageCandidates ?? []}
        onSelect={handleSelectPhoto}
      />

      <AlertDialog
        open={deletingBlock !== null}
        onOpenChange={(open) => {
          if (!open) setDeletingBlock(null);
        }}
      >
        <AlertDialogContent size="sm">
          <AlertDialogHeader>
            <AlertDialogMedia>
              <Trash2 />
            </AlertDialogMedia>
            <AlertDialogTitle>Удалить блок?</AlertDialogTitle>
            <AlertDialogDescription>
              Блок «{deletingBlock?.title}» будет удалён из собранного сайта.
              Это действие нельзя отменить.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={handleDelete}>
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
