"use client";

import { useState, type FormEvent } from "react";
import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Field, FieldError, FieldLabel } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { blockFormSchema, type BlockFormValues } from "@/lib/validation/block";

interface BlockFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "add" | "edit";
  initial?: BlockFormValues;
  onSubmit: (values: BlockFormValues) => void;
}

export function BlockFormDialog({
  open,
  onOpenChange,
  mode,
  initial,
  onSubmit,
}: BlockFormDialogProps) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [text, setText] = useState(initial?.text ?? "");
  const [fieldErrors, setFieldErrors] = useState<{
    title?: string;
    text?: string;
  }>({});

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const parsed = blockFormSchema.safeParse({ title, text });
    if (!parsed.success) {
      const flattened = parsed.error.flatten().fieldErrors;
      setFieldErrors({
        title: flattened.title?.[0],
        text: flattened.text?.[0],
      });
      return;
    }
    onSubmit(parsed.data);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Новый блок" : "Редактирование блока"}
          </DialogTitle>
          <DialogDescription>
            {mode === "add"
              ? "Добавьте смысловой блок со своим текстом. Он сразу появится в собранном сайте."
              : "Измените заголовок или текст блока — правки сразу появятся в собранном сайте."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Field data-invalid={fieldErrors.title ? true : undefined}>
            <FieldLabel htmlFor="block-title">Заголовок</FieldLabel>
            <Input
              id="block-title"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Например, Наши преимущества"
              aria-invalid={fieldErrors.title ? true : undefined}
              maxLength={200}
            />
            {fieldErrors.title ? (
              <FieldError>{fieldErrors.title}</FieldError>
            ) : null}
          </Field>
          <Field data-invalid={fieldErrors.text ? true : undefined}>
            <FieldLabel htmlFor="block-text">Текст</FieldLabel>
            <Textarea
              id="block-text"
              value={text}
              onChange={(event) => setText(event.target.value)}
              placeholder="Введите текст смыслового блока…"
              aria-invalid={fieldErrors.text ? true : undefined}
              maxLength={5000}
              className="min-h-32"
            />
            {fieldErrors.text ? (
              <FieldError>{fieldErrors.text}</FieldError>
            ) : null}
          </Field>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Отмена
            </Button>
            <Button type="submit">
              <Save />
              {mode === "add" ? "Добавить блок" : "Сохранить"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
