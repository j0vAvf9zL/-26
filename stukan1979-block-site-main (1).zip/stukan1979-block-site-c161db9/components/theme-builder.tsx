"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import {
  ArrowRight,
  Blocks,
  Clock,
  FolderOpen,
  Globe,
  LayoutPanelTop,
  ListPlus,
  LoaderCircle,
  Sparkles,
  Square,
  Wand2,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { SiteWorkspace } from "@/components/site-workspace";
import type { BlocksResult } from "@/lib/block-generator";
import type { SavedSite } from "@/lib/models";

const MIN_SITES = 1;
const MAX_SITES = 20;
const BETWEEN_SITES_DELAY_MS = 1200;

async function fetchBlocks(
  count: number,
  signal?: AbortSignal
): Promise<BlocksResult> {
  const response = await fetch(`/api/blocks?count=${count}`, { signal });
  if (!response.ok) {
    throw new Error("Не удалось собрать сайт");
  }
  return (await response.json()) as BlocksResult;
}

async function createSiteRecord(
  data: BlocksResult,
  signal?: AbortSignal
): Promise<SavedSite> {
  const response = await fetch("/api/sites", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      topic: data.topic,
      blocks: data.blocks,
      autoPicked: data.autoPicked,
      sources: data.sources,
    }),
    signal,
  });
  if (!response.ok) throw new Error("Не удалось сохранить сайт");
  return (await response.json()) as SavedSite;
}

function delay(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    function onAbort() {
      clearTimeout(timer);
      resolve();
    }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

function parseSiteCount(value: string): number {
  const count = Number(value.trim());
  return Number.isInteger(count) ? count : NaN;
}

function siteDate(iso: string): string {
  return new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function pluralizeBlocks(count: number): string {
  if (count % 10 === 1 && count % 100 !== 11) return `${count} блок`;
  if (
    count % 10 >= 2 &&
    count % 10 <= 4 &&
    (count % 100 < 12 || count % 100 > 14)
  ) {
    return `${count} блока`;
  }
  return `${count} блоков`;
}

export function ThemeBuilder() {
  const [siteCount, setSiteCount] = useState("5");
  const [result, setResult] = useState<BlocksResult | null>(null);
  const [siteId, setSiteId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [collectedCount, setCollectedCount] = useState(0);
  const [savedSites, setSavedSites] = useState<SavedSite[]>([]);
  const [workspaceKey, setWorkspaceKey] = useState<string>(() =>
    crypto.randomUUID()
  );
  const workspaceRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const fetchSavedSites = useCallback(async () => {
    try {
      const response = await fetch("/api/sites");
      if (!response.ok) return;
      const data = (await response.json()) as SavedSite[];
      setSavedSites(data);
    } catch {
      // список сохраняется как есть при недоступности API
    }
  }, []);

  useEffect(() => {
    void fetchSavedSites();
  }, [fetchSavedSites]);

  const handleSiteSaved = useCallback(() => {
    void fetchSavedSites();
  }, [fetchSavedSites]);

  async function runAutoCollect(count: number) {
    const runToastId = toast.loading("Начинаем непрерывный сбор сайтов…");
    setLoading(true);
    setResult(null);
    setSiteId(null);
    setCollectedCount(0);
    let collected = 0;
    let stopped = false;
    let failed = false;

    try {
      while (!stopped) {
        const controller = new AbortController();
        abortRef.current = controller;

        const data = await fetchBlocks(count, controller.signal);
        if (controller.signal.aborted) {
          stopped = true;
          break;
        }

        const saved = await createSiteRecord(data, controller.signal);
        if (controller.signal.aborted) {
          stopped = true;
          break;
        }

        collected += 1;
        setCollectedCount(collected);
        setWorkspaceKey(crypto.randomUUID());
        setSiteId(saved.id);
        setResult(data);
        void fetchSavedSites();
        toast.loading(`Собрано сайтов: ${collected}. Готовим следующий сайт…`, {
          id: runToastId,
        });

        await delay(BETWEEN_SITES_DELAY_MS, controller.signal);
        if (controller.signal.aborted) {
          stopped = true;
          break;
        }
      }
    } catch {
      if (abortRef.current?.signal.aborted) {
        stopped = true;
      } else {
        failed = true;
      }
    } finally {
      abortRef.current = null;
      setLoading(false);
      if (failed) {
        toast.error("Не удалось собрать сайт. Попробуйте ещё раз.", {
          id: runToastId,
        });
      } else if (stopped) {
        toast("Сборка остановлена", { id: runToastId });
      }
    }
  }

  function stopBuilding() {
    abortRef.current?.abort();
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const count = parseSiteCount(siteCount);
    if (Number.isNaN(count) || count < MIN_SITES || count > MAX_SITES) {
      toast(`Укажите количество сайтов от ${MIN_SITES} до ${MAX_SITES}`);
      return;
    }
    void runAutoCollect(count);
    workspaceRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }

  function openSavedSite(site: SavedSite) {
    abortRef.current?.abort();
    setWorkspaceKey(site.id);
    setSiteId(site.id);
    setResult({
      topic: site.topic,
      blocks: site.blocks,
      autoPicked: site.autoPicked,
      sources: site.sources,
    });
    workspaceRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }

  const sortedSites = [...savedSites].sort((a, b) =>
    b.updatedAt.localeCompare(a.updatedAt)
  );

  return (
    <div className="relative">
      <div
        aria-hidden
        className="pattern-grid pointer-events-none absolute inset-x-0 top-0 -z-10 h-72 opacity-40"
      />

      <section className="mx-auto w-full max-w-3xl px-4 pt-16 pb-8 text-center sm:pt-24">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border bg-background/80 px-4 py-1.5 text-sm text-muted-foreground shadow-sm backdrop-blur">
          <Sparkles className="h-4 w-4 text-primary" />
          Сайт из смысловых блоков — нажмите «Собрать сайт»
        </div>

        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
          Готовый сайт по одной{" "}
          <span className="gradient-hero-vibrant bg-clip-text text-transparent">
            кнопке
          </span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
          Один клик «Собрать сайт» запускает непрерывный сбор: БлокСайт сам
          придумывает тему, подбирает сайты из интернета и сохраняет готовый
          сайт — затем сразу начинает следующий. Сбор продолжается, пока вы не
          нажмёте «Остановить».
        </p>

        <form onSubmit={handleSubmit} className="mx-auto mt-8 max-w-xl">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="flex-1 text-left">
              <Label
                htmlFor="site-count"
                className="mb-2 block text-sm font-medium text-muted-foreground"
              >
                Сколько источников N на один сайт?
              </Label>
              <Input
                id="site-count"
                type="number"
                inputMode="numeric"
                min={MIN_SITES}
                max={MAX_SITES}
                step={1}
                value={siteCount}
                onChange={(event) => setSiteCount(event.target.value)}
                placeholder={`от ${MIN_SITES} до ${MAX_SITES}`}
                aria-label="Количество сайтов"
                disabled={loading}
                className="h-12 w-full rounded-xl bg-background text-base shadow-sm"
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="submit"
                size="lg"
                className="h-12 rounded-xl px-6"
                disabled={loading}
              >
                {loading ? (
                  <LoaderCircle className="animate-spin" />
                ) : (
                  <Wand2 />
                )}
                Собрать сайт
              </Button>
              {loading ? (
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  className="h-12 rounded-xl px-5"
                  onClick={stopBuilding}
                >
                  <Square className="h-4 w-4" />
                  Остановить
                </Button>
              ) : null}
            </div>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            N — сколько сайтов из интернета объединит каждый собранный сайт.
            Сбор идёт без остановки до нажатия «Остановить».
          </p>
        </form>
      </section>

      <section className="mx-auto w-full max-w-5xl px-4 pb-20">
        <div ref={workspaceRef} className="scroll-mt-20">
          {result ? (
            <div className="space-y-4">
              {loading ? (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-background px-4 py-3 shadow-sm">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <LoaderCircle className="h-4 w-4 animate-spin text-primary" />
                    Идёт непрерывный сбор: сохранено сайтов — {collectedCount}
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={stopBuilding}
                  >
                    <Square className="h-4 w-4" />
                    Остановить
                  </Button>
                </div>
              ) : null}
              <SiteWorkspace
                key={workspaceKey}
                result={result}
                initialSiteId={siteId}
                onSiteSaved={handleSiteSaved}
              />
            </div>
          ) : loading ? (
            <div className="grid gap-4 sm:grid-cols-2">
              {Array.from({ length: 6 }).map((_, index) => (
                <Card key={index}>
                  <Skeleton className="h-36 rounded-none border-b" />
                  <CardHeader>
                    <Skeleton className="h-5 w-2/3" />
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-11/12" />
                    <Skeleton className="h-4 w-4/5" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed bg-background px-6 py-14 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Blocks className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">
                Нажмите «Собрать сайт» — и здесь один за другим появятся
                собранные сайты по автоматически выбранным темам.
              </p>
            </div>
          )}
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Blocks className="h-4 w-4" />
          Блокам автоматически подобраны фотографии — их можно заменить или
          убрать, а правки сразу видны в собранном сайте
          <ArrowRight className="h-4 w-4" />
        </div>

        <div className="mt-14">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-xl font-semibold tracking-tight">
                <FolderOpen className="h-5 w-5 text-primary" />
                Сохранённые сайты
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Каждый собранный сайт сохраняется автоматически и всегда
                доступен для открытия.
              </p>
            </div>
            <SiteCountBadge count={sortedSites.length} />
          </div>

          {sortedSites.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed bg-background px-6 py-12 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Globe className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">
                Пока нет сохранённых сайтов. Соберите первый сайт — он появится
                здесь автоматически.
              </p>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {sortedSites.map((site) => (
                <Card
                  key={site.id}
                  className="card-hover animate-in fade-in slide-in-from-bottom-4 duration-500"
                >
                  <CardHeader>
                    <CardTitle className="truncate">{site.topic}</CardTitle>
                    <CardDescription className="flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {siteDate(site.updatedAt)}
                      </span>
                      <span aria-hidden>·</span>
                      <span className="inline-flex items-center gap-1">
                        <LayoutPanelTop className="h-3.5 w-3.5" />
                        {pluralizeBlocks(site.blocks.length)}
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardAction>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mr-4 mt-1"
                      onClick={() => openSavedSite(site)}
                    >
                      <ListPlus />
                      Открыть
                    </Button>
                  </CardAction>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function SiteCountBadge({ count }: { count: number }) {
  return (
    <Badge variant="outline" className="gap-1.5 px-3 py-1">
      <FolderOpen className="h-3.5 w-3.5" />
      {count} {count === 1 ? "сайт" : count < 5 ? "сайта" : "сайтов"}
    </Badge>
  );
}
