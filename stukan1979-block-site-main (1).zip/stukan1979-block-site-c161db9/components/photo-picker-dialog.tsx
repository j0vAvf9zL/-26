"use client";

import { useEffect, useState } from "react";
import { ImageIcon, LoaderCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";

interface PhotoPickerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  topic: string;
  currentImage: string | null;
  initialCandidates: string[];
  onSelect: (url: string) => void;
}

async function fetchPhotoCandidates(
  topic: string,
  title: string
): Promise<string[]> {
  const params = new URLSearchParams();
  if (topic) params.set("topic", topic);
  params.set("title", title);
  const response = await fetch(`/api/photos?${params.toString()}`);
  if (!response.ok) {
    throw new Error("Не удалось подобрать фотографии");
  }
  const data = (await response.json()) as { photos: string[] };
  return data.photos;
}

export function PhotoPickerDialog({
  open,
  onOpenChange,
  title,
  topic,
  currentImage,
  initialCandidates,
  onSelect,
}: PhotoPickerDialogProps) {
  const [candidates, setCandidates] = useState<string[]>(initialCandidates);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setCandidates(initialCandidates);
      setLoading(false);
    }
  }, [open, initialCandidates]);

  async function handleRefetch() {
    setLoading(true);
    try {
      const photos = await fetchPhotoCandidates(topic, title);
      setCandidates(photos.length > 0 ? photos : candidates);
      toast.success("Подобраны другие фотографии");
    } catch {
      toast.error(
        "Не удалось подобрать другие фотографии. Попробуйте ещё раз."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Фотография блока</DialogTitle>
          <DialogDescription>
            Фотографии подобраны автоматически по теме блока «{title}». Выберите
            одну из них или найдите другие.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          {currentImage ? (
            <img
              src={currentImage}
              alt={`Текущая фотография блока «${title}»`}
              className="h-40 w-full rounded-lg object-cover ring-1 ring-foreground/10"
            />
          ) : (
            <div className="flex h-40 flex-col items-center justify-center gap-2 rounded-lg bg-muted text-sm text-muted-foreground">
              <ImageIcon className="h-6 w-6" />У блока сейчас нет фотографии —
              выберите одну ниже.
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-3 gap-2">
              {Array.from({ length: 6 }).map((_, index) => (
                <Skeleton key={index} className="aspect-[4/3] rounded-lg" />
              ))}
            </div>
          ) : candidates.length > 0 ? (
            <div className="grid grid-cols-3 gap-2">
              {candidates.map((url) => (
                <button
                  key={url}
                  type="button"
                  onClick={() => onSelect(url)}
                  aria-label="Выбрать эту фотографию"
                  className="group relative aspect-[4/3] overflow-hidden rounded-lg ring-1 ring-foreground/10 transition-all hover:ring-2 hover:ring-primary"
                >
                  <img
                    src={url}
                    alt=""
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              Фотографии не нашлись. Попробуйте подобрать другие.
            </p>
          )}

          <Button
            type="button"
            variant="outline"
            onClick={handleRefetch}
            disabled={loading}
          >
            {loading ? (
              <LoaderCircle className="animate-spin" />
            ) : (
              <RefreshCw />
            )}
            Подобрать другие
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
