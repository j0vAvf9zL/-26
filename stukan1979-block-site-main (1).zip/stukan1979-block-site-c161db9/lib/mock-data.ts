// Мок-данные для статического режима (без БД)
// Используются когда USE_DATABASE=false или БД недоступна

import { Service, SavedSite } from "./models";

export const mockServices: Service[] = [
  {
    id: "mock-service-1",
    name: "API Gateway",
    description: "Шлюз для микросервисной архитектуры",
    status: "active",
    url: "https://api.example.com",
    createdAt: new Date("2024-01-15").toISOString(),
    updatedAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "mock-service-2",
    name: "Auth Service",
    description: "Сервис аутентификации и авторизации",
    status: "active",
    url: "https://auth.example.com",
    createdAt: new Date("2024-02-01").toISOString(),
    updatedAt: new Date("2024-02-01").toISOString(),
  },
  {
    id: "mock-service-3",
    name: "ML Pipeline",
    description: "Пайплайн для обработки данных с AI",
    status: "deploying",
    url: undefined,
    createdAt: new Date("2024-03-10").toISOString(),
    updatedAt: new Date("2024-03-10").toISOString(),
  },
];

export const mockSites: SavedSite[] = [
  {
    id: "mock-site-coffee",
    topic: "Уютная кофейня",
    blocks: [
      {
        id: "mock-coffee-about",
        title: "О нас",
        text: "Кофейня — это место, где встречаются аромат свежеобжаренного зерна и тёплая атмосфера. Здесь можно работать за ноутбуком, встречаться с друзьями или просто неспешно пить любимый напиток в окружении мягкого света и уютного интерьера.",
        image: null,
        imageCandidates: [],
      },
      {
        id: "mock-coffee-menu",
        title: "Меню и ассортимент",
        text: "Эспрессо, капучино, фильтр-кофе, какао и домашние лимонады. К кофе подают круассаны, чизкейки и свежую выпечку. Все напитки готовятся на цельном молоке, а для гостей с особыми предпочтениями есть растительные альтернативы.",
        image: null,
        imageCandidates: [],
      },
      {
        id: "mock-coffee-atmosphere",
        title: "Атмосфера и пространство",
        text: "Продуманный интерьер, удобные кресла, розетки у каждого столика и тихая музыка создают место, куда хочется возвращаться. Кофейня подходит и для встреч, и для уединённой работы над проектом.",
        image: null,
        imageCandidates: [],
      },
    ],
    autoPicked: true,
    sources: 3,
    createdAt: new Date("2024-04-02").toISOString(),
    updatedAt: new Date("2024-04-02").toISOString(),
  },
  {
    id: "mock-site-travel",
    topic: "Путешествия",
    blocks: [
      {
        id: "mock-travel-overview",
        title: "Путешествия",
        text: "Путешествия расширяют кругозор, дарят новые впечатления и знакомства. Не обязательно уезжать далеко: даже выходные в соседнем городе могут стать маленьким приключением, если продумать маршрут.",
        image: null,
        imageCandidates: [],
      },
      {
        id: "mock-travel-plan",
        title: "Планирование поездки",
        text: "Начните с бюджета и сроков, затем выбирайте направление и бронируйте жильё заранее. Оставляйте в плане свободные дни для спонтанных решений — самые яркие воспоминания часто появляются именно так.",
        image: null,
        imageCandidates: [],
      },
      {
        id: "mock-travel-culture",
        title: "Локальная культура",
        text: "Пробуйте местную кухню, гуляйте по нетуристическим кварталам и узнавайте город через его жителей. Рынки, маленькие кафе и семейные музеи рассказывают о месте больше, чем популярные достопримечательности.",
        image: null,
        imageCandidates: [],
      },
    ],
    autoPicked: false,
    sources: 0,
    createdAt: new Date("2024-04-05").toISOString(),
    updatedAt: new Date("2024-04-05").toISOString(),
  },
];
