import {
  linkAbort,
  pickPhotosForBlocks,
  throwIfAborted,
} from "@/lib/photo-picker";

export { BuildAbortedError, throwIfAborted } from "@/lib/photo-picker";

export interface GeneratedBlock {
  id: string;
  title: string;
  text: string;
  image: string | null;
  imageCandidates: string[];
}

export interface BlocksResult {
  topic: string;
  blocks: GeneratedBlock[];
  autoPicked: boolean;
  sources: number;
}

interface TopicEntry {
  keywords: string[];
  blocks: Array<{ title: string; text: string }>;
}

const TOPIC_KNOWLEDGE_BASE: TopicEntry[] = [
  {
    keywords: ["кофейн", "кофе"],
    blocks: [
      {
        title: "О нас",
        text: "Кофейня — это место, где встречаются аромат свежеобжаренного зерна и тёплая атмосфера. Здесь можно работать за ноутбуком, встречаться с друзьями или просто неспешно пить любимый напиток в окружении мягкого света и уютного интерьера.",
      },
      {
        title: "Наши преимущества",
        text: "Свежеобжаренное зерно каждую неделю, авторские десерты от местной кондитерской и бариста, которые помнят ваш заказ. Меню обновляется каждый сезон, а каждое утро гостей ждут сытные завтраки и альтернативные способы заваривания кофе.",
      },
      {
        title: "Меню и ассортимент",
        text: "Эспрессо, капучино, фильтр-кофе, какао и домашние лимонады. К кофе подают круассаны, чизкейки и свежую выпечку. Все напитки готовятся на цельном молоке, а для гостей с особыми предпочтениями есть растительные альтернативы.",
      },
      {
        title: "Атмосфера и пространство",
        text: "Продуманный интерьер, удобные кресла, розетки у каждого столика и тихая музыка создают место, куда хочется возвращаться. Кофейня подходит и для встреч, и для уединённой работы над проектом.",
      },
      {
        title: "Контакты и адрес",
        text: "Мы находимся в центре города, открыты ежедневно с 8:00 до 22:00. Следите за новинками меню и событиями в наших соцсетях — там мы публикуем анонсы дегустаций и мастер-классов.",
      },
    ],
  },
  {
    keywords: ["кулинари", "готовк", "рецепт", "выпечк"],
    blocks: [
      {
        title: "Кулинария — искусство и наука",
        text: "Кулинария объединяет традиции разных народов, современные техники и любовь к простым ингредиентам. Из базовых продуктов можно создавать настоящие шедевры, если понимать, как работают температура, время и специи.",
      },
      {
        title: "Базовые техники",
        text: "Умение правильно нарезать овощи, доводить соусы до нужной консистенции и определять готовность мяса — фундамент любой кухни. Освоив несколько приёмов, вы сократите время готовки и улучшите вкус привычных блюд.",
      },
      {
        title: "Сезонные продукты",
        text: "Блюда из сезонных овощей, фруктов и ягод получаются ярче и полезнее. Летом — лёгкие салаты и холодные супы, осенью — тыква и грибы, зимой — сытные запеканки, весной — первая зелень и ягоды.",
      },
      {
        title: "Идеи для дома",
        text: "Даже из скромного набора продуктов можно собрать ужин на двоих: паста с соусом, овощной гратен и простой десерт. Планируйте меню на неделю заранее — это экономит время, деньги и силы.",
      },
    ],
  },
  {
    keywords: ["фитнес", "здоров", "спорт", "трениров"],
    blocks: [
      {
        title: "Фитнес и здоровье",
        text: "Регулярные тренировки укрепляют сердце, улучшают сон и настроение. Главное правило — постепенность: начинайте с комфортной нагрузки и увеличивайте её по мере роста выносливости.",
      },
      {
        title: "Силовые тренировки",
        text: "Работа с собственным весом, гантелями или резинками помогает сохранять мышцы и плотность костей. Достаточно двух-трёх занятий в неделю, чтобы почувствовать результат уже через месяц.",
      },
      {
        title: "Питание и восстановление",
        text: "Сбалансированное питание с достаточным количеством белка и отдых между тренировками важны не меньше самих занятий. Сон не менее семи часов и регулярное восстановление защищают от перетренированности.",
      },
      {
        title: "Как начать",
        text: "Начните с коротких занятий дома или в зале, поставьте понятную цель и найдите удобное время в расписании. Даже 30 минут активности в день заметно улучшают самочувствие и уровень энергии.",
      },
    ],
  },
  {
    keywords: ["путешеств", "тур", "отпуск", "отдых"],
    blocks: [
      {
        title: "Путешествия",
        text: "Путешествия расширяют кругозор, дарят новые впечатления и знакомства. Не обязательно уезжать далеко: даже выходные в соседнем городе могут стать маленьким приключением, если продумать маршрут.",
      },
      {
        title: "Планирование поездки",
        text: "Начните с бюджета и сроков, затем выбирайте направление и бронируйте жильё заранее. Оставляйте в плане свободные дни для спонтанных решений — самые яркие воспоминания часто появляются именно так.",
      },
      {
        title: "Локальная культура",
        text: "Пробуйте местную кухню, гуляйте по нетуристическим кварталам и узнавайте город через его жителей. Рынки, маленькие кафе и семейные музеи рассказывают о месте больше, чем популярные достопримечательности.",
      },
      {
        title: "Советы путешественнику",
        text: "Собирайте вещи накануне, храните копии документов в облаке и возьмите с собой компактную аптечку. Страховка и универсальный адаптер для розеток решают большинство проблем в дороге.",
      },
    ],
  },
  {
    keywords: ["йог", "медитац", "дыхани"],
    blocks: [
      {
        title: "Студия йоги",
        text: "Йога — это практика тела, дыхания и внимания. Она помогает снять напряжение, улучшить гибкость и найти внутреннее равновесие. Заниматься может каждый независимо от возраста и уровня подготовки.",
      },
      {
        title: "Направления",
        text: "Хатха подойдёт новичкам, виньяса — тем, кто хочет динамики, а йога-нидра и медитации помогают восстановиться после напряжённого дня. Инструкторы помогут подобрать подходящий формат занятий.",
      },
      {
        title: "Польза регулярной практики",
        text: "Регулярные занятия улучшают осанку, сон и концентрацию, снижают уровень стресса. Уже через несколько недель практики вы заметите, как легче становится дышать и двигаться в повседневной жизни.",
      },
      {
        title: "Что взять с собой",
        text: "Удобную одежду, которая не сковывает движения, бутылку воды и желание заниматься. Коврики и всё необходимое есть в студии, а после класса вас ждёт расслабляющий чай.",
      },
    ],
  },
  {
    keywords: ["детск", "ребен", "развити"],
    blocks: [
      {
        title: "Детский клуб",
        text: "Детский клуб — пространство, где ребёнок учится, играет и находит друзей. В безопасной и яркой среде дети развивают воображение, логику и навыки общения через творчество и командные игры.",
      },
      {
        title: "Программы занятий",
        text: "Мы предлагаем развивающие занятия для разных возрастов: раннее развитие, подготовка к школе, творческие мастер-классы, шахматы и робототехника. Каждая программа построена в игровой форме.",
      },
      {
        title: "Педагоги и атмосфера",
        text: "Занятия ведут опытные педагоги, которые умеют увлечь ребёнка и поддержать его любознательность. Небольшие группы позволяют уделить внимание каждому участнику.",
      },
      {
        title: "Праздники и будни",
        text: "В клубе проходят дни рождения, сезонные праздники и тематические недели. Родители могут оставить ребёнка на пару часов или провести время в уютной зоне ожидания с кофе.",
      },
    ],
  },
];

const GENERIC_TEMPLATES: Array<{
  title: (topic: string) => string;
  text: (topic: string) => string;
}> = [
  {
    title: () => "Обзор темы",
    text: (topic) =>
      `«${topic}» — тема, которая объединяет практический опыт, современные тенденции и живой интерес людей. Разберёмся в главном: что важно знать, с чего начать и на что обратить внимание в первую очередь.`,
  },
  {
    title: () => "Ключевые идеи",
    text: (topic) =>
      `В основе темы «${topic}» лежат несколько простых идей: начать с малого, действовать регулярно и опираться на проверенные источники. Именно они помогают превращать интерес в устойчивый навык и ощутимый результат.`,
  },
  {
    title: () => "С чего начать",
    text: (topic) =>
      `Чтобы погрузиться в тему «${topic}», достаточно сделать первый шаг: изучить базовые понятия, посмотреть примеры и попробовать на практике. Не старайтесь охватить всё сразу — двигайтесь небольшими шагами.`,
  },
  {
    title: () => "Частые ошибки",
    text: (topic) =>
      `Новички часто перегружают себя информацией, ждут мгновенного результата и пропускают основы. В теме «${topic}» важно сохранять последовательность и не бояться ошибок — они часть любого пути.`,
  },
  {
    title: () => "Советы и вдохновение",
    text: (topic) =>
      `Ищите вдохновение в успешных примерах и общайтесь с теми, кто уже давно в теме «${topic}». Окружение единомышленников поддерживает мотивацию, а маленькие победы постепенно складываются в большой результат.`,
  },
];

const AUTO_TOPIC_POOL = [
  "Уютная кофейня",
  "Кулинария",
  "Фитнес и здоровье",
  "Путешествия",
  "Студия йоги",
  "Детский клуб",
  "Домашняя выпечка",
  "Здоровое питание",
  "Семейный отдых",
  "Развитие детей",
  "Настольные игры",
  "Современное искусство",
];

export function generateRandomTopic(): string {
  const index = Math.floor(Math.random() * AUTO_TOPIC_POOL.length);
  return AUTO_TOPIC_POOL[index] ?? AUTO_TOPIC_POOL[0];
}

function normalizeTopic(topic: string): string {
  return topic.trim().toLowerCase();
}

function findKnowledgeEntry(topic: string): TopicEntry | null {
  const normalized = normalizeTopic(topic);
  return (
    TOPIC_KNOWLEDGE_BASE.find((entry) =>
      entry.keywords.some((keyword) => normalized.includes(keyword))
    ) ?? null
  );
}

function idFromText(text: string, index: number, source = 0): string {
  const slug = text
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);
  const prefix = source > 0 ? `${source}-` : "";
  return `${prefix}${slug || "block"}-${index + 1}`;
}

function buildBlocks(
  topic: string,
  raw: Array<{ title: string; text: string }>,
  source = 0
): GeneratedBlock[] {
  return raw.map((item, index) => ({
    id: idFromText(item.title, index, source),
    title: item.title,
    text: item.text,
    image: null,
    imageCandidates: [],
  }));
}

function genericBlocks(topic: string): GeneratedBlock[] {
  return buildBlocks(
    topic,
    GENERIC_TEMPLATES.map((template) => ({
      title: template.title(topic),
      text: template.text(topic),
    }))
  );
}

function knowledgeBlocks(topic: string): GeneratedBlock[] {
  const entry = findKnowledgeEntry(topic);
  if (!entry) return [];
  return buildBlocks(topic, entry.blocks);
}

function cleanParagraph(text: string): string {
  let out = text
    .replace(/\[\d+\]/g, "")
    .replace(/\[(?:править|edit)\]/gi, "")
    .replace(/\[[^\]\n]*\]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return out;
}

function truncateAtSentence(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  const slice = text.slice(0, maxLength);
  const match = slice.match(/[.!?…]\s/g);
  if (!match) return `${slice.trim()}…`;
  const endIndex = slice.lastIndexOf(match[match.length - 1][0]);
  return `${slice.slice(0, endIndex + 1)}`;
}

function isSkippedHeading(title: string): boolean {
  const lowered = title.toLowerCase();
  return [
    "см. также",
    "примечания",
    "литература",
    "ссылки",
    "источники",
    "внешние ссылки",
    "смотри также",
  ].some((item) => lowered.includes(item));
}

interface ParsedSection {
  title: string;
  paragraphs: string[];
}

function parseExtractIntoBlocks(
  extract: string
): Array<{ title: string; text: string }> {
  const sections: ParsedSection[] = [];
  let currentTitle = "";
  let currentParagraphs: string[] = [];

  for (const rawLine of extract.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;

    const headingMatch = line.match(/^==+\s*(.*?)\s*==+$/);
    if (headingMatch) {
      const heading = cleanParagraph(headingMatch[1]);
      if (currentParagraphs.length > 0) {
        sections.push({
          title: currentTitle || "Обзор",
          paragraphs: currentParagraphs,
        });
      }
      currentTitle = heading;
      currentParagraphs = [];
      continue;
    }

    const cleaned = cleanParagraph(line);
    if (cleaned.length < 120) continue;
    if (/^[IVXLC]+\.?\s/m.test(cleaned)) continue;
    currentParagraphs.push(cleaned);
  }

  if (currentParagraphs.length > 0) {
    sections.push({
      title: currentTitle || "Обзор",
      paragraphs: currentParagraphs,
    });
  }

  const blocks: Array<{ title: string; text: string }> = [];
  for (const section of sections) {
    if (isSkippedHeading(section.title)) continue;
    const paragraphs = section.paragraphs.filter(
      (paragraph) => paragraph.length >= 150 && paragraph.length <= 1200
    );
    if (paragraphs.length === 0) continue;

    const text = truncateAtSentence(paragraphs.join(" "), 700);
    if (text.length < 150) continue;

    const title =
      section.title !== "Обзор"
        ? truncateAtSentence(section.title, 60)
        : "Обзор темы";
    blocks.push({ title, text });
  }

  return blocks.slice(0, 6);
}

const WIKI_API = "https://ru.wikipedia.org/w/api.php";
const WIKI_HEADERS = {
  "User-Agent": "BlokSitePrototype/1.0 (automated content picking)",
};

const MAX_SOURCE_COUNT = 20;
const SEARCH_TIMEOUT_MS = 5000;
const EXTRACT_TIMEOUT_MS = 7000;
const EXTRACT_CONCURRENCY = 6;
const MAX_BLOCKS_PER_SOURCE = 3;
const MAX_TOTAL_BLOCKS = 48;
const SEARCH_CANDIDATE_FACTOR = 2;
const SEARCH_CANDIDATE_BUFFER = 3;

const GENERIC_TOPIC_WORDS = new Set([
  "уютная",
  "уютный",
  "домашняя",
  "домашний",
  "семейный",
  "семейная",
  "современное",
  "современный",
  "здоровое",
  "здоровый",
  "студия",
  "клуб",
  "развитие",
  "настольные",
  "лучший",
  "лучшие",
  "лучшая",
  "идея",
  "идеи",
  "онлайн",
  "как",
  "что",
  "для",
  "сайт",
  "тема",
]);

function normalizeKeyword(word: string): string {
  return word
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]/gi, "")
    .trim();
}

function extractPrimaryKeyword(topic: string): string | null {
  const words = topic.split(/\s+/).map(normalizeKeyword).filter(Boolean);
  const meaningful = words.filter(
    (word) => word.length > 3 && !GENERIC_TOPIC_WORDS.has(word)
  );
  const candidates = meaningful.length > 0 ? meaningful : words;
  const sorted = [...new Set(candidates)].sort((a, b) => b.length - a.length);
  return sorted[0] ?? null;
}

function buildSearchQueries(topic: string): string[] {
  const queries: string[] = [];
  const trimmedTopic = topic.trim();
  const keyword = extractPrimaryKeyword(trimmedTopic);
  if (keyword) queries.push(keyword);
  if (keyword !== trimmedTopic.toLowerCase()) queries.push(trimmedTopic);
  return [...new Set(queries)];
}

function dedupeTitles(titles: string[]): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const title of titles) {
    const key = title.trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    if (title.includes("(значения)")) continue;
    seen.add(key);
    result.push(title.trim());
  }
  return result;
}

async function searchWikiArticleTitles(
  query: string,
  limit: number,
  signal?: AbortSignal
): Promise<string[]> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), SEARCH_TIMEOUT_MS);
  const unlink = linkAbort(controller, signal);

  try {
    const searchParams = new URLSearchParams({
      action: "query",
      format: "json",
      list: "search",
      srsearch: query,
      srlimit: String(Math.min(Math.max(limit, 1), 50)),
      srnamespace: "0",
      utf8: "1",
    });

    const response = await fetch(`${WIKI_API}?${searchParams.toString()}`, {
      signal: controller.signal,
      headers: WIKI_HEADERS,
    });
    if (!response.ok) return [];

    const data = (await response.json()) as {
      query?: { search?: Array<{ title: string }> };
    };
    return dedupeTitles((data.query?.search ?? []).map((item) => item.title));
  } catch {
    throwIfAborted(signal);
    return [];
  } finally {
    clearTimeout(timeoutId);
    unlink();
  }
}

async function fetchExtractForTitle(
  title: string,
  signal?: AbortSignal
): Promise<string | null> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), EXTRACT_TIMEOUT_MS);
  const unlink = linkAbort(controller, signal);

  try {
    const extractParams = new URLSearchParams({
      action: "query",
      format: "json",
      prop: "extracts",
      explaintext: "1",
      exsectionformat: "wiki",
      redirects: "1",
      exlimit: "1",
      titles: title,
      utf8: "1",
    });

    const response = await fetch(`${WIKI_API}?${extractParams.toString()}`, {
      signal: controller.signal,
      headers: WIKI_HEADERS,
    });
    if (!response.ok) return null;

    const data = (await response.json()) as {
      query?: { pages?: Record<string, { extract?: string }> };
    };
    const page = Object.values(data.query?.pages ?? {})[0];
    return page?.extract ?? null;
  } catch {
    throwIfAborted(signal);
    return null;
  } finally {
    clearTimeout(timeoutId);
    unlink();
  }
}

async function fetchExtractsForTitles(
  titles: string[],
  signal?: AbortSignal
): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  let nextIndex = 0;

  async function runWorker() {
    while (nextIndex < titles.length) {
      throwIfAborted(signal);
      const index = nextIndex;
      nextIndex += 1;
      const title = titles[index];
      const extract = await fetchExtractForTitle(title, signal);
      if (extract) result.set(title, extract);
    }
  }

  const workers = Array.from(
    { length: Math.min(EXTRACT_CONCURRENCY, titles.length) },
    () => runWorker()
  );
  await Promise.all(workers);

  return result;
}

async function fetchFromInternet(
  topic: string,
  count: number,
  signal?: AbortSignal
): Promise<{ blocks: GeneratedBlock[]; sources: number } | null> {
  const target = Math.min(Math.max(count, 1), MAX_SOURCE_COUNT);
  const candidateLimit = Math.min(
    target * SEARCH_CANDIDATE_FACTOR + SEARCH_CANDIDATE_BUFFER,
    50
  );

  const rawCandidates: string[] = [];
  for (const query of buildSearchQueries(topic)) {
    throwIfAborted(signal);
    const titles = await searchWikiArticleTitles(query, candidateLimit, signal);
    rawCandidates.push(...titles);
  }
  const titles = dedupeTitles(rawCandidates);
  if (titles.length === 0) return null;

  const extractsByTitle = await fetchExtractsForTitles(titles, signal);

  const blocksPerSource = Math.max(
    1,
    Math.min(MAX_BLOCKS_PER_SOURCE, Math.floor(MAX_TOTAL_BLOCKS / target))
  );

  const allBlocks: GeneratedBlock[] = [];
  let sources = 0;

  for (const title of titles) {
    throwIfAborted(signal);
    if (sources >= target) break;
    const extract = extractsByTitle.get(title);
    if (!extract) continue;

    const parsed = parseExtractIntoBlocks(extract);
    if (parsed.length === 0) continue;

    const sourceBlocks = buildBlocks(
      topic,
      parsed.slice(0, blocksPerSource),
      sources + 1
    );
    allBlocks.push(...sourceBlocks);
    sources += 1;
  }

  if (allBlocks.length < 2) return null;

  return { blocks: allBlocks.slice(0, MAX_TOTAL_BLOCKS), sources };
}

export async function generateBlocksForTopic(
  topic: string,
  count = 5,
  signal?: AbortSignal
): Promise<BlocksResult> {
  const trimmedTopic = topic.trim();

  throwIfAborted(signal);
  const internetResult = await fetchFromInternet(trimmedTopic, count, signal);
  let blocks: GeneratedBlock[];
  let autoPicked: boolean;
  let sources: number;

  if (internetResult && internetResult.blocks.length >= 2) {
    blocks = internetResult.blocks;
    autoPicked = true;
    sources = internetResult.sources;
  } else {
    const knowledge = knowledgeBlocks(trimmedTopic);
    if (knowledge.length >= 2) {
      blocks = knowledge;
      autoPicked = false;
      sources = 0;
    } else {
      blocks = genericBlocks(trimmedTopic);
      autoPicked = false;
      sources = 0;
    }
  }

  throwIfAborted(signal);
  const photosByBlockId = await pickPhotosForBlocks(
    trimmedTopic,
    blocks,
    signal
  );
  const blocksWithPhotos = blocks.map((block) => {
    const candidates = photosByBlockId[block.id] ?? [];
    return {
      ...block,
      image: candidates[0] ?? null,
      imageCandidates: candidates,
    };
  });

  return {
    topic: trimmedTopic,
    blocks: blocksWithPhotos,
    autoPicked,
    sources,
  };
}
