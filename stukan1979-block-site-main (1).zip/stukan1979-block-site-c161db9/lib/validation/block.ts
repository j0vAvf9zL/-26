import { z } from "zod";

export const blockFormSchema = z.object({
  title: z
    .string()
    .trim()
    .min(1, "Введите заголовок блока")
    .max(200, "Заголовок не должен превышать 200 символов"),
  text: z
    .string()
    .trim()
    .min(1, "Введите текст блока")
    .max(5000, "Текст не должен превышать 5000 символов"),
});

export type BlockFormValues = z.infer<typeof blockFormSchema>;
