import { z } from "zod";

export const savedBlockSchema = z.object({
  id: z.string().trim().min(1).max(100),
  title: z
    .string()
    .trim()
    .min(1, "Введите заголовок блока")
    .max(200, "Заголовок не должен превышать 200 символов"),
  text: z
    .string()
    .trim()
    .min(1, "Введите текст блока")
    .max(5000, "Текст не должен превышать 5000 символов"),
  image: z
    .string()
    .trim()
    .max(5000, "Ссылка на изображение слишком длинная")
    .nullable(),
  imageCandidates: z
    .array(z.string().trim().max(5000, "Ссылка на изображение слишком длинная"))
    .max(50),
});

export const saveSiteSchema = z.object({
  topic: z
    .string()
    .trim()
    .min(1, "Введите тему сайта")
    .max(120, "Тема слишком длинная"),
  blocks: z.array(savedBlockSchema).max(100),
  autoPicked: z.boolean(),
  sources: z.number().int().min(0).max(100),
});

export const updateSiteSchema = saveSiteSchema.extend({
  id: z.string().trim().min(1).max(100),
});

export type SaveSiteValues = z.infer<typeof saveSiteSchema>;
