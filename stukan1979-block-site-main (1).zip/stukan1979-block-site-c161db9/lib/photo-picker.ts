const COMMONS_API = "https://commons.wikimedia.org/w/api.php";
const COMMONS_HEADERS = {
  "User-Agent": "BlokSitePrototype/1.0 (automated photo picking)",
};

const SEARCH_TIMEOUT_MS = 4500;
export const PHOTOS_PER_BLOCK = 10;
export const PHOTO_OPTIONS = 12;

export class BuildAbortedError extends Error {
  constructor() {
    super("Сборка прервана");
    this.name = "BuildAbortedError";
  }
}

export function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw new BuildAbortedError();
}

const STOP_WORDS = new Set([
  "и",
  "в",
  "во",
  "на",
  "с",
  "со",
  "по",
  "к",
  "у",
  "а",
  "но",
  "о",
  "об",
  "от",
  "для",
  "за",
  "из",
  "не",
  "же",
  "или",
  "это",
  "то",
  "что",
  "как",
  "все",
  "всех",
  "всего",
  "над",
  "под",
  "при",
  "до",
  "про",
  "наш",
  "наши",
  "наших",
  "тема",
  "тему",
  "блок",
  "раздел",
  "обзор",
]);

const UNSUPPORTED_FILE =
  /\.(?:svg|pdf|webm|ogv|ogg|oga|flac|mp3|wav|tif|tiff|djvu|xcf|exe|zip)$/i;

const FALLBACK_PHOTOS = [
  "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/960px-A_small_cup_of_coffee.JPG",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Lake_Tekapo_01.jpg/960px-Lake_Tekapo_01.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Bergen_city_centre_and_surroundings_Panorama_edited.jpg/960px-Bergen_city_centre_and_surroundings_Panorama_edited.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Egyptian_food_Koshary.jpg/960px-Egyptian_food_Koshary.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Austria_-_G%C3%B6ttweig_Abbey_-_2015.jpg/960px-Austria_-_G%C3%B6ttweig_Abbey_-_2015.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Himalayas%2C_Ama_Dablam%2C_Nepal.jpg/960px-Himalayas%2C_Ama_Dablam%2C_Nepal.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Sea_caves_Cape_Greco_9.jpg/960px-Sea_caves_Cape_Greco_9.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Moore_Street_market%2C_Dublin.jpg/960px-Moore_Street_market%2C_Dublin.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Cirrus_uncinus_clouds_in_the_morning_sky.jpg/960px-Cirrus_uncinus_clouds_in_the_morning_sky.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Parboiled_rice_with_chicken%2C_peppers%2C_cucurbita%2C_peas_and_tomato.jpg/960px-Parboiled_rice_with_chicken%2C_peppers%2C_cucurbita%2C_peas_and_tomato.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Sydney_Opera_House_-_Dec_2008.jpg/960px-Sydney_Opera_House_-_Dec_2008.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Taj_Mahal%2C_Agra%2C_India_edit3.jpg/960px-Taj_Mahal%2C_Agra%2C_India_edit3.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/960px-Colosseo_2020.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Machu_Picchu%2C_Peru.jpg/960px-Machu_Picchu%2C_Peru.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Grand_Canyon_view_from_Pima_Point_2010.jpg/960px-Grand_Canyon_view_from_Pima_Point_2010.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Mount_Everest_as_seen_from_Drukair2_PLW_edit.jpg/960px-Mount_Everest_as_seen_from_Drukair2_PLW_edit.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Aurora_borealis_over_Eielson_Air_Force_Base%2C_Alaska.jpg/960px-Aurora_borealis_over_Eielson_Air_Force_Base%2C_Alaska.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/SF_Golden_Gate_Bridge_splash_CA.jpg/960px-SF_Golden_Gate_Bridge_splash_CA.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Santorini_panoramic_from_the_crater_rim_above_Athinios_port_-_02.jpg/960px-Santorini_panoramic_from_the_crater_rim_above_Athinios_port_-_02.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Sunflower_field_-_panoramio_%2811%29.jpg/960px-Sunflower_field_-_panoramio_%2811%29.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/1/13/Tunnel_View%2C_Yosemite_Valley%2C_Yosemite_NP_-_Diliff.jpg/960px-Tunnel_View%2C_Yosemite_Valley%2C_Yosemite_NP_-_Diliff.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/20090529_Great_Wall_8185.jpg/960px-20090529_Great_Wall_8185.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Neuschwanstein_Castle_from_Marienbr%C3%BCcke%2C_2011_May.jpg/960px-Neuschwanstein_Castle_from_Marienbr%C3%BCcke%2C_2011_May.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Tour_Eiffel_Wikimedia_Commons.jpg/960px-Tour_Eiffel_Wikimedia_Commons.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/1_lake_louise_pano_2019.jpg/960px-1_lake_louise_pano_2019.jpg",
];

interface CommonsImageInfo {
  thumburl?: string;
  width?: number;
}

interface CommonsPage {
  title?: string;
  imageinfo?: CommonsImageInfo[];
}

interface CommonsSearchResponse {
  query?: { pages?: Record<string, CommonsPage> };
}

function stripQuery(url: string): string {
  return url.split("?")[0];
}

function dedupe(items: string[]): string[] {
  return [...new Set(items)];
}

function hashCode(value: string): number {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash << 5) - hash + value.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

export function linkAbort(
  controller: AbortController,
  signal?: AbortSignal
): () => void {
  if (!signal) return () => {};
  const onAbort = () => controller.abort();
  if (signal.aborted) {
    controller.abort();
  } else {
    signal.addEventListener("abort", onAbort, { once: true });
  }
  return () => signal.removeEventListener("abort", onAbort);
}

export function fallbackCandidates(seed: string, count: number): string[] {
  const result: string[] = [];
  const usedIndexes = new Set<number>();
  let salt = 0;
  while (result.length < count && usedIndexes.size < FALLBACK_PHOTOS.length) {
    const index = hashCode(`${seed}:${salt}`) % FALLBACK_PHOTOS.length;
    salt += 1;
    if (usedIndexes.has(index)) continue;
    usedIndexes.add(index);
    result.push(FALLBACK_PHOTOS[index]);
  }
  return result;
}

export function completeCandidates(
  candidates: string[],
  seed: string,
  target: number
): string[] {
  if (candidates.length >= target) return candidates.slice(0, target);
  const seen = new Set(candidates);
  const result = [...candidates];
  for (const photo of fallbackCandidates(seed, FALLBACK_PHOTOS.length)) {
    if (seen.has(photo)) continue;
    seen.add(photo);
    result.push(photo);
    if (result.length >= target) break;
  }
  return result;
}

function extractKeywords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^а-яёa-z0-9\s-]/gi, " ")
    .split(/\s+/)
    .filter((word) => word.length > 2 && !STOP_WORDS.has(word));
}

export function buildPhotoQueries(topic: string, title: string): string[] {
  const queries: string[] = [];
  const titleWords = extractKeywords(title);
  if (titleWords.length > 0) {
    queries.push(titleWords.slice(0, 3).join(" "));
  }
  const topicWords = extractKeywords(topic);
  if (topicWords.length > 0) {
    queries.push(topicWords.slice(0, 3).join(" "));
    if (titleWords.length > 0) {
      queries.push(`${topicWords[0]} ${titleWords[0]}`);
    }
  }
  return [...new Set(queries)].slice(0, 3);
}

export async function searchCommonsPhotos(
  query: string,
  limit = 12,
  signal?: AbortSignal
): Promise<string[]> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), SEARCH_TIMEOUT_MS);
  const unlink = linkAbort(controller, signal);

  try {
    const searchParams = new URLSearchParams({
      action: "query",
      format: "json",
      generator: "search",
      gsrsearch: query,
      gsrnamespace: "6",
      gsrlimit: String(Math.min(Math.max(limit, 1), 20)),
      prop: "imageinfo",
      iiprop: "url|size",
      iiurlwidth: "800",
    });

    const response = await fetch(`${COMMONS_API}?${searchParams.toString()}`, {
      signal: controller.signal,
      headers: COMMONS_HEADERS,
    });
    if (!response.ok) return [];

    const data = (await response.json()) as CommonsSearchResponse;
    const pages = Object.values(data.query?.pages ?? {});

    const photos: string[] = [];
    for (const page of pages) {
      const info = page.imageinfo?.[0];
      if (!info?.thumburl || !info.width || info.width < 600) continue;
      if (UNSUPPORTED_FILE.test(page.title ?? "")) continue;
      photos.push(stripQuery(info.thumburl));
    }
    return dedupe(photos);
  } catch {
    throwIfAborted(signal);
    return [];
  } finally {
    clearTimeout(timeoutId);
    unlink();
  }
}

export async function pickPhotoOptions(
  topic: string,
  title: string,
  target = PHOTO_OPTIONS,
  signal?: AbortSignal
): Promise<string[]> {
  const seen = new Set<string>();
  const candidates: string[] = [];

  for (const query of buildPhotoQueries(topic, title)) {
    throwIfAborted(signal);
    if (candidates.length >= target) break;
    const photos = await searchCommonsPhotos(query, 12, signal);
    for (const photo of photos) {
      if (seen.has(photo)) continue;
      seen.add(photo);
      candidates.push(photo);
      if (candidates.length >= target) break;
    }
  }

  if (candidates.length === 0) {
    return fallbackCandidates(`${topic}::${title}`, target);
  }
  return completeCandidates(candidates, `${topic}::${title}`, target);
}

async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<R>
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let nextIndex = 0;

  async function runWorker() {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      results[index] = await worker(items[index]);
    }
  }

  const workers = Array.from({ length: Math.min(limit, items.length) }, () =>
    runWorker()
  );
  await Promise.all(workers);
  return results;
}

export async function pickPhotosForBlocks(
  topic: string,
  blocks: Array<{ id: string; title: string }>,
  signal?: AbortSignal
): Promise<Record<string, string[]>> {
  const entries = await mapWithConcurrency(blocks, 6, async (block) => {
    throwIfAborted(signal);
    const candidates = await pickPhotoOptions(
      topic,
      block.title,
      PHOTOS_PER_BLOCK,
      signal
    );
    return [block.id, candidates] as const;
  });
  const result = Object.fromEntries(entries);

  const used = new Set<string>();
  const chosenByBlock = new Map<string, string>();

  for (const block of blocks) {
    const candidates = result[block.id] ?? [];
    if (candidates.length === 0) continue;
    const chosen = candidates.find((url) => !used.has(url)) ?? candidates[0];
    chosenByBlock.set(block.id, chosen);
    used.add(chosen);
  }

  for (const block of blocks) {
    const candidates = result[block.id] ?? [];
    const chosen = chosenByBlock.get(block.id);
    if (!chosen || candidates.length === 0) continue;
    const othersChosen = new Set(
      [...chosenByBlock.entries()]
        .filter(([id]) => id !== block.id)
        .map(([, url]) => url)
    );
    result[block.id] = [
      chosen,
      ...candidates.filter((url) => url !== chosen && !othersChosen.has(url)),
    ].slice(0, PHOTOS_PER_BLOCK);
  }

  return result;
}
