import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { PHOTO_OPTIONS, pickPhotoOptions } from "@/lib/photo-picker";

const photosQuerySchema = z.object({
  topic: z.string().trim().max(200).optional(),
  title: z
    .string()
    .trim()
    .min(1, "Укажите блок для подбора фотографий")
    .max(200, "Заголовок слишком длинный"),
});

export async function GET(request: NextRequest) {
  const parsed = photosQuerySchema.safeParse({
    topic: request.nextUrl.searchParams.get("topic") ?? undefined,
    title: request.nextUrl.searchParams.get("title"),
  });

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректный запрос", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const photos = await pickPhotoOptions(
    parsed.data.topic ?? parsed.data.title,
    parsed.data.title,
    PHOTO_OPTIONS
  );

  return NextResponse.json({ photos });
}
