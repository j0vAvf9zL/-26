import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { createSite, getAllSites, getSiteById, updateSite } from "@/lib/models";
import { mockSites } from "@/lib/mock-data";
import { saveSiteSchema, updateSiteSchema } from "@/lib/validation/site";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      const sites = await getAllSites();
      return NextResponse.json(sites);
    } catch (error) {
      console.error("Ошибка получения сохранённых сайтов:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json(mockSites);
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const parsed = saveSiteSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные сайта", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  try {
    const site = await createSite(parsed.data);
    return NextResponse.json(site, { status: 201 });
  } catch (error) {
    console.error("Ошибка сохранения сайта:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения сайта" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const parsed = updateSiteSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные данные сайта", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { id, ...data } = parsed.data;

  try {
    const existing = await getSiteById(id);
    if (!existing) {
      return NextResponse.json(
        { error: "Сохранённый сайт не найден" },
        { status: 404 }
      );
    }

    const site = await updateSite(id, data);
    return NextResponse.json(site);
  } catch (error) {
    console.error("Ошибка обновления сайта:", error);
    return NextResponse.json(
      { error: "Ошибка обновления сайта" },
      { status: 500 }
    );
  }
}
