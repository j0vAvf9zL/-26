import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import {
  BuildAbortedError,
  generateBlocksForTopic,
  generateRandomTopic,
} from "@/lib/block-generator";

const generateBlocksQuerySchema = z.object({
  topic: z
    .string()
    .trim()
    .min(1, "Введите тему")
    .max(120, "Тема слишком длинная")
    .nullable()
    .optional(),
  count: z.coerce
    .number()
    .int()
    .min(1, "Минимум один сайт")
    .max(20, "Максимум 20 сайтов")
    .default(5),
});

export async function GET(request: NextRequest) {
  const parsed = generateBlocksQuerySchema.safeParse({
    topic: request.nextUrl.searchParams.get("topic"),
    count: request.nextUrl.searchParams.get("count"),
  });

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректный запрос", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const topic = parsed.data.topic ?? generateRandomTopic();

  try {
    const result = await generateBlocksForTopic(
      topic,
      parsed.data.count,
      request.signal
    );
    return NextResponse.json(result);
  } catch (error) {
    if (error instanceof BuildAbortedError) {
      return NextResponse.json({ error: "Сборка отменена" }, { status: 499 });
    }
    console.error("Ошибка генерации блоков:", error);
    return NextResponse.json(
      { error: "Не удалось подобрать смысловые блоки" },
      { status: 500 }
    );
  }
}
