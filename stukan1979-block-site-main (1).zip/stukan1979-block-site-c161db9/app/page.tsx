import { ThemeBuilder } from "@/components/theme-builder";

export default function HomePage() {
  return <ThemeBuilder />;
}
